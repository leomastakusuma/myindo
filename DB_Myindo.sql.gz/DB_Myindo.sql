-- Adminer 4.1.0 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `T_Departemen`;
CREATE TABLE `T_Departemen` (
  `id_departemen` int(11) NOT NULL AUTO_INCREMENT,
  `departemen` varchar(50) NOT NULL,
  PRIMARY KEY (`id_departemen`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `T_Departemen` (`id_departemen`, `departemen`) VALUES
(1,	'Creative'),
(2,	'Project');

DROP TABLE IF EXISTS `T_Gaji`;
CREATE TABLE `T_Gaji` (
  `id_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `id_jabatan` int(11) NOT NULL,
  `gaji_pokok` decimal(10,0) NOT NULL,
  `tunjangan_fungsional` decimal(10,0) NOT NULL,
  `tunjangan_struktural` decimal(10,0) NOT NULL,
  `tunjangan_makan` decimal(10,0) NOT NULL,
  `tunjangan_transportasi` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id_gaji`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `T_Golongan`;
CREATE TABLE `T_Golongan` (
  `id_golongan` int(11) NOT NULL AUTO_INCREMENT,
  `id_jabatan` int(11) NOT NULL,
  `golongan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_golongan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `T_Golongan` (`id_golongan`, `id_jabatan`, `golongan`) VALUES
(3,	1,	'A'),
(4,	1,	's'),
(5,	16,	'1'),
(6,	16,	'KASDASD'),
(7,	11,	'SDASDasd'),
(8,	11,	'ASDAsd');

DROP TABLE IF EXISTS `T_Jabatan`;
CREATE TABLE `T_Jabatan` (
  `id_jabatan` int(11) NOT NULL AUTO_INCREMENT,
  `jabatan` varchar(50) NOT NULL,
  PRIMARY KEY (`id_jabatan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `T_Jabatan` (`id_jabatan`, `jabatan`) VALUES
(11,	'Manager'),
(12,	'Staf'),
(13,	'Application Enginer'),
(14,	'Accounting'),
(15,	'Technical Writer'),
(16,	'IT Support');

DROP TABLE IF EXISTS `T_Karyawan`;
CREATE TABLE `T_Karyawan` (
  `id_Karyawan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_karyawan` varchar(50) NOT NULL,
  `ttl` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(15) NOT NULL,
  `umur` varchar(4) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `agama` varchar(15) NOT NULL,
  `gol_darah` varchar(15) NOT NULL,
  `stat_kawin` varchar(15) NOT NULL,
  `kwn` varchar(15) NOT NULL,
  `no_telp` int(12) NOT NULL,
  `no_ktp` int(12) NOT NULL,
  `npwp` int(12) NOT NULL,
  `id_departemen` int(11) NOT NULL,
  `id_jabatan` int(11) NOT NULL,
  `id_golongan` int(11) NOT NULL,
  `stat_pegawai` varchar(15) NOT NULL,
  `tgl_masuk` date NOT NULL,
  PRIMARY KEY (`id_Karyawan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `T_Karyawan` (`id_Karyawan`, `nama_karyawan`, `ttl`, `jenis_kelamin`, `umur`, `alamat`, `agama`, `gol_darah`, `stat_kawin`, `kwn`, `no_telp`, `no_ktp`, `npwp`, `id_departemen`, `id_jabatan`, `id_golongan`, `stat_pegawai`, `tgl_masuk`) VALUES
(4,	'Aldhonie',	'Metro, 3 April 1991',	'L',	'23',	'Jl. Veteran No.7 ',	'Islam',	'0',	'Kawin',	'WNI',	2147483647,	2147483647,	2147483647,	1,	16,	5,	'Magang',	'0000-00-00');

DROP TABLE IF EXISTS `T_Potongan`;
CREATE TABLE `T_Potongan` (
  `Id_Potongan` int(11) NOT NULL AUTO_INCREMENT,
  `Jth` decimal(10,0) NOT NULL,
  `PPH21` decimal(10,0) NOT NULL,
  `Presensi` int(2) NOT NULL,
  PRIMARY KEY (`Id_Potongan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- 2014-07-02 07:18:41
